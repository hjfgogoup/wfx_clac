var price;
var cost ; //商品价格,成本价

var distribution;//分销佣金

var orderer_1 , 
    orderer_2 ,
    orderer_3 ,
    orderer_4 ,
    orderer_5 ;//订货商1-5级

var proxy_1, proxy_2, proxy_3;//代理商1-3级

var sales_award, team_award, ex_award;//订货商销售奖,订货商团队业绩,商家额外

var sales_award_P, team_award_P, ex_award_P;


//参数传递,获取对应ID值

function getIdvalue(n){
    return parseFloat(document.getElementById(n).value);
}

//计算订货商差价部分的佣金支出
function costOrderer(){
    if(getIdvalue("orderer_1") != 0){
        return  (getIdvalue("orderer_1")/100)*getIdvalue("price");
    }else if(getIdvalue("orderer_2") != 0){
        return  (getIdvalue("orderer_2")/100)*getIdvalue("price");
    }else if(getIdvalue("orderer_3") != 0){
        return  (getIdvalue("orderer_3")/100)*getIdvalue("price");
    }else if(getIdvalue("orderer_4") != 0){
        return  (getIdvalue("orderer_4")/100)*getIdvalue("price");
    }else return  (getIdvalue("orderer_5")/100)*getIdvalue("price");
}


//计算商家最后剩的钱
function ordererProfit(){
    var a = getIdvalue("price");
    var b = getIdvalue("cost");
    var c = (getIdvalue("sales_award")+getIdvalue("team_award"))*getIdvalue("price")/100 + getIdvalue("ex_award");
    var d = getIdvalue("distributiondis")*getIdvalue("price")/100;
    var radio = document.getElementsByName("distributionFromOrderer");
    var selectvalue=null;   //  selectvalue为radio中选中的值
        for(var i=0;i<radio.length;i++){
            if(radio[i].checked==true) { 
                selectvalue=radio[i].value;
                break;
            }  
        }
    if ( selectvalue == 1){
        //alert(selectvalue);
        return costOrderer()-b-c;
    }else {
        //alert(selectvalue);
        return costOrderer()-b-c-d;
    }
}
//订货商版本计算商家的净利率
function R_orderer(){ 
    return ordererProfit()/getIdvalue("price");
}	

function foo1(){
    document.getElementById("money1").innerHTML=ordererProfit();
    document.getElementById("r1").innerHTML=R_orderer();
    
}
/*----------------------------------------------------------------------------------------------------------------------------------*/
//计算代理佣金总支出
function costProxy1(){
    return (getIdvalue("proxy_1")+getIdvalue("proxy_2")+getIdvalue("proxy_3"))*getIdvalue("price")/100;
}

function costProxy2(){
    if(getIdvalue("proxy_1") !=0){
        return (getIdvalue("proxy_1")/100)*getIdvalue("price");
    }else if(getIdvalue("proxy_2") !=0){
        return (getIdvalue("proxy_2")/100)*getIdvalue("price");
    }else return (getIdvalue("proxy_3")/100)*getIdvalue("price");
}
function costProxy3(){
    return (getIdvalue("proxy_1")+getIdvalue("proxy_2")+getIdvalue("proxy_3"))*(getIdvalue("price")-getIdvalue("cost"))/100;                                                                
}

function costProxy4(){
    if(getIdvalue("proxy_1") !=0){
        return (getIdvalue("proxy_1")/100)*(getIdvalue("price")-getIdvalue("cost"));
    }else if(getIdvalue("proxy_2") !=0){
        return (getIdvalue("proxy_2")/100)*(getIdvalue("price")-getIdvalue("cost"));
    }else return (getIdvalue("proxy_3")/100)*(getIdvalue("price")-getIdvalue("cost"));                                                                
}
//计算代理商最后剩的钱

function proxyProfit(){
    var a = getIdvalue("price");
    var b = getIdvalue("cost");
    var c = (getIdvalue("sales_award_P")+getIdvalue("team_award_P"))*getIdvalue("price")/100 + getIdvalue("ex_award_P");
    var d = getIdvalue("distributiondis")*getIdvalue("price")/100;
    var e = (getIdvalue("sales_award_P")+getIdvalue("team_award_P"))*(getIdvalue("price")-getIdvalue("cost"))/100 + getIdvalue("ex_award_P")
    var f = getIdvalue("distributiondis")*(getIdvalue("price")-getIdvalue("cost"))/100;
    var radio = document.getElementsByName("proxyFromHigh");
    var selectvalue=null;   //  selectvalue为radio中选中的值
        for(var i=0;i<radio.length;i++){
            if(radio[i].checked==true) { 
                selectvalue=radio[i].value;
                break;
            }  
        }
    var radio_2 = document.getElementsByName("clacByProfit");
    var selectvalue2=null;   //  selectvalue为radio中选中的值
        for(var i=0;i<radio_2.length;i++){
            if(radio_2[i].checked==true) { 
                selectvalue2=radio_2[i].value;
                break;
            }  
        }
    if(selectvalue == 1 && selectvalue2 == 0){
            //alert(selectvalue);    
        return a-b-c-d-costProxy2();
    }else if(selectvalue == 0 && selectvalue2 == 0){
            //alert(selectvalue);
        return a-b-c-d-costProxy1();
    }else if (selectvalue == 1 && selectvalue2 == 1) {
        return a-b-e-f-costProxy4();
    }else return a-b-e-f-costProxy3();
}

//计算代理商净利率
function R_proxy(){
    return proxyProfit()/getIdvalue("price");
}

function foo2(){
    
    document.getElementById("money2").innerHTML=proxyProfit();
    document.getElementById("r2").innerHTML=R_proxy();
    /*alert(getIdvalue("price"));
    alert(getIdvalue("cost"));
    alert(getIdvalue("distributiondis"));
    alert(getIdvalue("proxy_1"));
    alert(getIdvalue("proxy_2"));
    alert(getIdvalue("proxy_3"));
    alert(getIdvalue("sales_award_P"));
    alert(getIdvalue("team_award_P"));
    alert(getIdvalue("ex_award_P"));
    alert(getIdvalue("proxyFromHigh"));
    */
}